import os
import wx
from controls.window_tools import load_settings, update_settings

try:
    import fitz
except ImportError:
    fitz = None


DEFAULT_OPTIMIZE_IMAGE_WIDTH = 1000
DEFAULT_OPTIMIZE_IMAGE_QUALITY = 70
DEFAULT_COLOR_TARGET_DPI = 110
DEFAULT_COLOR_THRESHOLD_DPI = 140
DEFAULT_COLOR_COMPRESSION = "jpeg"
DEFAULT_COLOR_QUALITY = "medium"
DEFAULT_MONO_TARGET_DPI = 110
DEFAULT_MONO_THRESHOLD_DPI = 140
DEFAULT_MONO_COMPRESSION = "png"
DEFAULT_COMPRESS_ONLY_IF_RESIZED = False
PDF_PREVIEW_RENDER_QUALITY_MULTIPLIER = 3.5
PDF_PREVIEW_MIN_RENDER_SCALE = 0.75
PDF_PREVIEW_MAX_RENDER_SCALE = 2.5
PDF_PREVIEW_MAX_RENDER_HEIGHT = 1600
DEFAULT_SHOW_PAGES_LIMIT = 10
DEFAULT_PDF_SHOW_PAGES_LIMIT = 50
DEFAULT_WORD_SHOW_PAGES_LIMIT = 10
DEFAULT_EXCEL_SHOW_PAGES_LIMIT = 1
DEFAULT_OTHER_SHOW_PAGES_LIMIT = 10
_PDF_SESSION_BYTES = {}


def _normalize_show_pages_limit(raw_limit, default_limit):
    try:
        limit = int(raw_limit)
    except (TypeError, ValueError):
        limit = default_limit
    return max(1, limit)


def _get_show_pages_limit_for_path(path):
    settings = load_settings()
    if isinstance(path, str):
        _, ext = os.path.splitext(path)
        ext = ext.lower()
        if ext == ".pdf":
            key = "pdf_show_pages_limit"
            default_limit = DEFAULT_PDF_SHOW_PAGES_LIMIT
        elif ext in {".doc", ".docx", ".docm"}:
            key = "word_show_pages_limit"
            default_limit = DEFAULT_WORD_SHOW_PAGES_LIMIT
        elif ext in {".xls", ".xlsx", ".xlsm"}:
            key = "excel_show_pages_limit"
            default_limit = DEFAULT_EXCEL_SHOW_PAGES_LIMIT
        else:
            key = "other_show_pages_limit"
            default_limit = DEFAULT_OTHER_SHOW_PAGES_LIMIT
    else:
        key = "pdf_show_pages_limit"
        default_limit = DEFAULT_PDF_SHOW_PAGES_LIMIT

    raw_limit = settings.get(key, settings.get("show_pages_limit", default_limit))
    limit = _normalize_show_pages_limit(raw_limit, default_limit)
    legacy_key = settings.get("show_pages_limit")
    if key not in settings and legacy_key is None:
        try:
            update_settings({key: limit})
        except Exception:
            pass
    return limit


def _get_show_pages_limit():
    return _get_show_pages_limit_for_path("document.pdf")


def _get_optimize_pdf_settings():
    settings = load_settings()

    width = settings.get("optimize_pdf_image_width", DEFAULT_OPTIMIZE_IMAGE_WIDTH)
    quality = settings.get("optimize_pdf_image_quality", DEFAULT_OPTIMIZE_IMAGE_QUALITY)

    try:
        width = int(width)
    except (TypeError, ValueError):
        width = DEFAULT_OPTIMIZE_IMAGE_WIDTH

    try:
        quality = int(quality)
    except (TypeError, ValueError):
        quality = DEFAULT_OPTIMIZE_IMAGE_QUALITY

    width = max(1, width)
    quality = min(100, max(1, quality))

    update_settings(
        {
            "optimize_pdf_image_width": width,
            "optimize_pdf_image_quality": quality,
        }
    )
    return width, quality


def _normalize_dpi(value, default_value):
    try:
        value = int(value)
    except (TypeError, ValueError):
        value = default_value
    return max(1, value)


def _normalize_bool(value, default_value):
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in {"1", "true", "yes", "y", "on"}:
            return True
        if lowered in {"0", "false", "no", "n", "off"}:
            return False
    return default_value


def _normalize_choice(value, default_value, allowed_values):
    if not isinstance(value, str):
        return default_value
    normalized = value.strip().lower()
    if normalized in allowed_values:
        return normalized
    return default_value


def _normalize_color_quality(value):
    if isinstance(value, int):
        return min(100, max(1, value))

    if isinstance(value, str):
        normalized = value.strip().lower()
        quality_map = {
            "low": 20,
            "medium": 35,
            "high": 55,
        }
        if normalized in quality_map:
            return quality_map[normalized]
        try:
            return min(100, max(1, int(normalized)))
        except (TypeError, ValueError):
            return _normalize_color_quality(DEFAULT_COLOR_QUALITY)

    return _normalize_color_quality(DEFAULT_COLOR_QUALITY)


def _get_optimize_pdf_advanced_settings():
    settings = load_settings()

    color_target_dpi = _normalize_dpi(
        settings.get("optimize_pdf_color_target_dpi", DEFAULT_COLOR_TARGET_DPI),
        DEFAULT_COLOR_TARGET_DPI,
    )
    color_threshold_dpi = _normalize_dpi(
        settings.get("optimize_pdf_color_threshold_dpi", DEFAULT_COLOR_THRESHOLD_DPI),
        DEFAULT_COLOR_THRESHOLD_DPI,
    )
    color_compression = _normalize_choice(
        settings.get("optimize_pdf_color_compression", DEFAULT_COLOR_COMPRESSION),
        DEFAULT_COLOR_COMPRESSION,
        {"jpeg", "png"},
    )
    color_quality = _normalize_color_quality(
        settings.get("optimize_pdf_color_quality", DEFAULT_COLOR_QUALITY)
    )

    mono_target_dpi = _normalize_dpi(
        settings.get("optimize_pdf_mono_target_dpi", DEFAULT_MONO_TARGET_DPI),
        DEFAULT_MONO_TARGET_DPI,
    )
    mono_threshold_dpi = _normalize_dpi(
        settings.get("optimize_pdf_mono_threshold_dpi", DEFAULT_MONO_THRESHOLD_DPI),
        DEFAULT_MONO_THRESHOLD_DPI,
    )
    mono_compression = _normalize_choice(
        settings.get("optimize_pdf_mono_compression", DEFAULT_MONO_COMPRESSION),
        DEFAULT_MONO_COMPRESSION,
        {"ccitt_group3", "ccitt_group4", "png"},
    )
    compress_only_if_resized = _normalize_bool(
        settings.get(
            "optimize_pdf_compress_only_if_resized",
            DEFAULT_COMPRESS_ONLY_IF_RESIZED,
        ),
        DEFAULT_COMPRESS_ONLY_IF_RESIZED,
    )

    update_settings(
        {
            "optimize_pdf_color_target_dpi": color_target_dpi,
            "optimize_pdf_color_threshold_dpi": color_threshold_dpi,
            "optimize_pdf_color_compression": color_compression,
            "optimize_pdf_color_quality": color_quality,
            "optimize_pdf_mono_target_dpi": mono_target_dpi,
            "optimize_pdf_mono_threshold_dpi": mono_threshold_dpi,
            "optimize_pdf_mono_compression": mono_compression,
            "optimize_pdf_compress_only_if_resized": compress_only_if_resized,
        }
    )

    return {
        "color_target_dpi": color_target_dpi,
        "color_threshold_dpi": color_threshold_dpi,
        "color_compression": color_compression,
        "color_quality": color_quality,
        "mono_target_dpi": mono_target_dpi,
        "mono_threshold_dpi": mono_threshold_dpi,
        "mono_compression": mono_compression,
        "compress_only_if_resized": compress_only_if_resized,
    }


def _get_max_image_dpi(page, xref, pixel_width, pixel_height):
    max_dpi = 0.0
    try:
        rects = page.get_image_rects(xref)
    except Exception:
        rects = []

    for rect in rects:
        if rect.width <= 0 or rect.height <= 0:
            continue
        dpi_x = (float(pixel_width) * 72.0) / float(rect.width)
        dpi_y = (float(pixel_height) * 72.0) / float(rect.height)
        max_dpi = max(max_dpi, dpi_x, dpi_y)

    return max_dpi


def _get_target_size_from_dpi(source_pix, target_dpi, source_dpi):
    if source_dpi <= 0:
        return source_pix.width, source_pix.height

    scale = float(target_dpi) / float(source_dpi)
    if scale >= 1.0:
        return source_pix.width, source_pix.height

    target_width = max(1, int(round(source_pix.width * scale)))
    target_height = max(1, int(round(source_pix.height * scale)))
    return target_width, target_height


def _encode_pixmap_bytes(scaled_pix, is_monochrome, advanced_settings, fallback_quality):
    if is_monochrome:
        mono_compression = advanced_settings["mono_compression"]

        # PyMuPDF does not expose direct CCITT encoding for replace_image streams.
        # PNG keeps monochrome scans lossless and compact.
        if mono_compression in {"ccitt_group3", "ccitt_group4", "png"}:
            return scaled_pix.tobytes("png")

    color_compression = advanced_settings["color_compression"]
    if color_compression == "png":
        return scaled_pix.tobytes("png")

    color_quality = advanced_settings["color_quality"]
    try:
        return scaled_pix.tobytes("jpg", jpg_quality=color_quality)
    except TypeError:
        try:
            return scaled_pix.tobytes("jpg", jpg_quality=fallback_quality)
        except TypeError:
            return scaled_pix.tobytes("jpg")


def is_pdf_file(path):
    return isinstance(path, str) and path.lower().endswith(".pdf")


def _normalize_pdf_session_path(path):
    return os.path.normpath(path)


def _get_pdf_session_bytes(path):
    return _PDF_SESSION_BYTES.get(_normalize_pdf_session_path(path))


def _set_pdf_session_bytes(path, pdf_bytes):
    _PDF_SESSION_BYTES[_normalize_pdf_session_path(path)] = pdf_bytes


def has_unsaved_pdf_changes(path):
    return isinstance(path, str) and _normalize_pdf_session_path(path) in _PDF_SESSION_BYTES


def get_unsaved_pdf_paths():
    return sorted(_PDF_SESSION_BYTES.keys())


def discard_pdf_changes(path):
    if isinstance(path, str):
        _PDF_SESSION_BYTES.pop(_normalize_pdf_session_path(path), None)


def _read_pdf_bytes(path):
    if not os.path.isfile(path):
        raise FileNotFoundError(path)

    session_bytes = _get_pdf_session_bytes(path)
    if session_bytes is not None:
        return session_bytes

    with open(path, "rb") as handle:
        return handle.read()


def _open_pdf_document(path):
    return fitz.open(stream=_read_pdf_bytes(path), filetype="pdf")


def _store_pdf_document(path, doc, **save_kwargs):
    _set_pdf_session_bytes(path, doc.tobytes(**save_kwargs))
    return path


def save_pdf(path):
    if fitz is None:
        raise RuntimeError("PyMuPDF is not installed. PDF preview unavailable.")

    if not os.path.isfile(path):
        raise FileNotFoundError(path)

    session_bytes = _get_pdf_session_bytes(path)
    if session_bytes is None:
        return path

    with open(path, "wb") as handle:
        handle.write(session_bytes)

    discard_pdf_changes(path)
    return path


def save_pdf_as(path, new_path):
    if fitz is None:
        raise RuntimeError("PyMuPDF is not installed. PDF preview unavailable.")

    if not os.path.isfile(path):
        raise FileNotFoundError(path)

    if not isinstance(new_path, str) or not new_path.strip():
        raise ValueError("A target PDF path is required.")

    new_path = os.path.normpath(new_path)
    if os.path.normpath(path) == new_path:
        return save_pdf(path)

    pdf_bytes = _read_pdf_bytes(path)
    parent_dir = os.path.dirname(new_path)
    if parent_dir and not os.path.isdir(parent_dir):
        raise FileNotFoundError(parent_dir)

    with open(new_path, "wb") as handle:
        handle.write(pdf_bytes)

    discard_pdf_changes(path)
    discard_pdf_changes(new_path)
    return new_path


def get_pdf_page_count(path):
    if fitz is None:
        raise RuntimeError("PyMuPDF is not installed. PDF preview unavailable.")

    doc = _open_pdf_document(path)
    try:
        return len(doc)
    finally:
        doc.close()


def move_pdf_page(path, from_index, to_index):
    if fitz is None:
        raise RuntimeError("PyMuPDF is not installed. PDF preview unavailable.")

    doc = _open_pdf_document(path)
    try:
        page_count = len(doc)
        if not 0 <= from_index < page_count:
            raise ValueError(f"Page index {from_index} is out of range")
        if not 0 <= to_index < page_count:
            raise ValueError(f"Target index {to_index} is out of range")
        if from_index == to_index:
            return path

        order = list(range(page_count))
        page = order.pop(from_index)
        insert_at = to_index
        order.insert(insert_at, page)

        new_doc = fitz.open()
        try:
            for index in order:
                new_doc.insert_pdf(doc, from_page=index, to_page=index)

            return _store_pdf_document(path, new_doc, garbage=4, deflate=True, clean=True)
        finally:
            if not new_doc.is_closed:
                new_doc.close()
    finally:
        doc.close()


def import_pdf_pages(path, source_path, insert_at_index):
    if fitz is None:
        raise RuntimeError("PyMuPDF is not installed. PDF preview unavailable.")

    if not os.path.isfile(path):
        raise FileNotFoundError(path)
    if not os.path.isfile(source_path):
        raise FileNotFoundError(source_path)

    target_doc = _open_pdf_document(path)
    source_doc = _open_pdf_document(source_path)
    new_doc = fitz.open()
    try:
        target_page_count = len(target_doc)
        insert_at_index = max(0, min(target_page_count, int(insert_at_index)))

        if insert_at_index > 0:
            new_doc.insert_pdf(target_doc, from_page=0, to_page=insert_at_index - 1)

        if len(source_doc) > 0:
            new_doc.insert_pdf(source_doc)

        if insert_at_index < target_page_count:
            new_doc.insert_pdf(target_doc, from_page=insert_at_index, to_page=target_page_count - 1)

        return _store_pdf_document(path, new_doc, garbage=4, deflate=True, clean=True)
    finally:
        target_doc.close()
        source_doc.close()
        if not new_doc.is_closed:
            new_doc.close()


def export_pdf_pages(path, page_indices, output_path):
    if fitz is None:
        raise RuntimeError("PyMuPDF is not installed. PDF preview unavailable.")

    if not os.path.isfile(path):
        raise FileNotFoundError(path)
    if not isinstance(output_path, str) or not output_path.strip():
        raise ValueError("A target PDF path is required.")

    output_path = os.path.normpath(output_path)
    if os.path.normpath(path) == output_path:
        raise ValueError("Export target must be a different file.")

    source_doc = _open_pdf_document(path)
    new_doc = fitz.open()
    try:
        page_count = len(source_doc)
        normalized_indices = []
        for page_index in page_indices:
            normalized_index = int(page_index)
            if not 0 <= normalized_index < page_count:
                raise ValueError(f"Page index {normalized_index} is out of range")
            normalized_indices.append(normalized_index)

        if not normalized_indices:
            raise ValueError("At least one page must be selected.")

        for normalized_index in normalized_indices:
            new_doc.insert_pdf(source_doc, from_page=normalized_index, to_page=normalized_index)

        parent_dir = os.path.dirname(output_path)
        if parent_dir and not os.path.isdir(parent_dir):
            raise FileNotFoundError(parent_dir)

        new_doc.save(output_path, garbage=4, deflate=True, clean=True)
        return output_path
    finally:
        source_doc.close()
        if not new_doc.is_closed:
            new_doc.close()


def rotate_pdf(path, angle=90):
    if fitz is None:
        raise RuntimeError("PyMuPDF is not installed. PDF preview unavailable.")

    doc = _open_pdf_document(path)
    try:
        for page in doc:
            page.set_rotation((page.rotation + angle) % 360)

        return _store_pdf_document(path, doc, garbage=4, deflate=True, clean=True)
    finally:
        doc.close()


# def auto_rotate_pdf(path):
#     if fitz is None:
#         raise RuntimeError("PyMuPDF is not installed. PDF preview unavailable.")

#     doc = _open_pdf_document(path)
#     try:
#         for page in doc:
#             if page.rotation != 0:
#                 page.set_rotation(0)

#         return _store_pdf_document(path, doc, garbage=4, deflate=True, clean=True)
#     finally:
#         doc.close()


def rotate_pdf_page(path, page_index, angle=90):
    if fitz is None:
        raise RuntimeError("PyMuPDF is not installed. PDF preview unavailable.")

    doc = _open_pdf_document(path)
    try:
        if not 0 <= page_index < len(doc):
            raise ValueError(f"Page index {page_index} is out of range")
        page = doc[page_index]
        page.set_rotation((page.rotation + angle) % 360)

        return _store_pdf_document(path, doc, garbage=4, deflate=True, clean=True)
    finally:
        doc.close()


def remove_pdf_page(path, page_index):
    if fitz is None:
        raise RuntimeError("PyMuPDF is not installed. PDF preview unavailable.")

    doc = _open_pdf_document(path)
    try:
        if not 0 <= page_index < len(doc):
            raise ValueError(f"Page index {page_index} is out of range")

        doc.delete_page(page_index)
        return _store_pdf_document(path, doc, garbage=4, deflate=True, clean=True)
    finally:
        doc.close()


def optimize_pdf(path):
    if fitz is None:
        raise RuntimeError("PyMuPDF is not installed. PDF preview unavailable.")

    target_width, target_quality = _get_optimize_pdf_settings()
    advanced_settings = _get_optimize_pdf_advanced_settings()

    doc = _open_pdf_document(path)
    try:
        processed_xrefs = set()
        for page in doc:
            page_images = page.get_images(full=True)
            for image_info in page_images:
                xref = image_info[0]
                if xref in processed_xrefs:
                    continue
                processed_xrefs.add(xref)

                try:
                    pix = fitz.Pixmap(doc, xref)
                except Exception:
                    continue

                source_pix = pix
                if pix.alpha:
                    try:
                        source_pix = fitz.Pixmap(fitz.csRGB, pix)
                    except Exception:
                        # Some image streams cannot be converted while changing alpha.
                        # Skip this image and continue optimizing others.
                        pix = None
                        continue

                if source_pix.width <= 0 or source_pix.height <= 0:
                    if source_pix is not pix:
                        source_pix = None
                    pix = None
                    continue

                max_dpi = _get_max_image_dpi(page, xref, source_pix.width, source_pix.height)
                bpc = image_info[4] if len(image_info) > 4 else None
                is_monochrome = bpc == 1

                if max_dpi > 0:
                    if is_monochrome:
                        target_dpi = advanced_settings["mono_target_dpi"]
                        threshold_dpi = advanced_settings["mono_threshold_dpi"]
                    else:
                        target_dpi = advanced_settings["color_target_dpi"]
                        threshold_dpi = advanced_settings["color_threshold_dpi"]

                    should_resize = max_dpi > threshold_dpi
                    if should_resize:
                        target_w, target_h = _get_target_size_from_dpi(source_pix, target_dpi, max_dpi)
                    else:
                        target_w, target_h = source_pix.width, source_pix.height
                else:
                    # Fallback for images where display rectangles are unavailable.
                    target_w = target_width
                    target_h = max(1, int(round(source_pix.height * (target_w / source_pix.width))))

                scaled_pix = source_pix
                resized = source_pix.width != target_w or source_pix.height != target_h
                if resized:
                    try:
                        scaled_pix = fitz.Pixmap(source_pix, target_w, target_h)
                    except Exception:
                        pix = None
                        if source_pix is not pix:
                            source_pix = None
                        continue

                if advanced_settings["compress_only_if_resized"] and not resized:
                    if scaled_pix is not source_pix:
                        scaled_pix = None
                    if source_pix is not pix:
                        source_pix = None
                    pix = None
                    continue

                try:
                    jpeg_bytes = _encode_pixmap_bytes(
                        scaled_pix,
                        is_monochrome,
                        advanced_settings,
                        target_quality,
                    )
                except Exception:
                    if scaled_pix is not source_pix:
                        scaled_pix = None
                    if source_pix is not pix:
                        source_pix = None
                    pix = None
                    continue

                try:
                    page.replace_image(xref, stream=jpeg_bytes)
                except Exception:
                    pass

                if scaled_pix is not source_pix:
                    scaled_pix = None
                if source_pix is not pix:
                    source_pix = None
                pix = None

        return _store_pdf_document(path, doc, garbage=4, deflate=True, clean=True)
    finally:
        doc.close()


def _is_scanned_single_image_pdf(doc):
    for page in doc:
        text = page.get_text("text")
        if text and text.strip():
            return False

    return True


def adjust_page_width(path):
    if fitz is None:
        raise RuntimeError("PyMuPDF is not installed. PDF preview unavailable.")

    doc = _open_pdf_document(path)
    new_doc = None
    try:
        if len(doc) == 0:
            return path

        new_doc = fitz.open()

        widths = []
        for page in doc:
            page_width = int(round(page.rect.width))
            if page_width > 0:
                widths.append(page_width)

        if not widths:
            return path

        width_counts = {}
        for width in widths:
            width_counts[width] = width_counts.get(width, 0) + 1

        target_width = max(width_counts.items(), key=lambda item: (item[1], item[0]))[0]

        for page_index in range(len(doc)):
            page = doc[page_index]
            src_width = float(page.rect.width)
            src_height = float(page.rect.height)
            if src_width <= 0 or src_height <= 0:
                new_doc.insert_pdf(doc, from_page=page_index, to_page=page_index)
                continue

            width_delta = abs(src_width - float(target_width))
            if width_delta <= 10.0:
                new_doc.insert_pdf(doc, from_page=page_index, to_page=page_index)
                continue

            scale = target_width / src_width
            page_width = float(target_width)
            page_height = max(1.0, src_height * scale)

            new_page = new_doc.new_page(width=page_width, height=page_height)
            pix = page.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False)
            new_page.insert_image(
                rect=new_page.rect,
                stream=pix.tobytes("png"),
            )

        return _store_pdf_document(path, new_doc, garbage=4, deflate=True, clean=True)
    finally:
        doc.close()
        if new_doc is not None and not new_doc.is_closed:
            new_doc.close()


def get_pdf_page_previews(path, max_height=300, max_pages=None, target_width=None, target_height=None, target_zoom=1.0, avg_width=None, avg_height=None, force_all_pages=False):
    if fitz is None:
        raise RuntimeError("PyMuPDF is not installed. PDF preview unavailable.")

    doc = _open_pdf_document(path)
    try:
        page_count = len(doc)
        settings_limit = _get_show_pages_limit_for_path(path)
        if force_all_pages:
            shown_pages = page_count
        elif max_pages is None:
            shown_pages = min(page_count, settings_limit)
        else:
            shown_pages = min(page_count, max_pages, settings_limit)
        previews = []

        if shown_pages <= 0:
            return page_count, shown_pages, previews

        if target_width is not None or target_height is not None:
            if avg_width is not None or avg_height is not None:
                avg_width_value = float(avg_width) if avg_width is not None and avg_width > 0 else None
                avg_height_value = float(avg_height) if avg_height is not None and avg_height > 0 else None

                if target_width is None and target_height is None:
                    common_scale = 1.0
                elif target_width is None:
                    common_scale = float(target_height) / float(avg_height_value or 1.0)
                elif target_height is None:
                    common_scale = float(target_width) / float(avg_width_value or 1.0)
                else:
                    if avg_width_value is not None:
                        common_scale = float(target_width) / float(avg_width_value or float(target_width))
                    elif avg_height_value is not None:
                        common_scale = float(target_height) / float(avg_height_value or float(target_height))
                    else:
                        common_scale = 1.0
            else:
                common_scale = 1.0

            for index in range(shown_pages):
                page = doc[index]
                rect = page.rect
                rect_width = float(rect.width) * common_scale
                rect_height = float(rect.height) * common_scale
                matrix = fitz.Matrix(
                    float(rect_width) / float(rect.width),
                    float(rect_height) / float(rect.height),
                )
                pix = page.get_pixmap(matrix=matrix, alpha=False)
                rgb_pix = pix if pix.n == 3 and not pix.alpha else fitz.Pixmap(fitz.csRGB, pix)
                bitmap = wx.Bitmap.FromBuffer(rgb_pix.width, rgb_pix.height, rgb_pix.samples)
                previews.append((index + 1, bitmap))

            return page_count, shown_pages, previews

        # Use a single scale for all pages so different original page widths/heights
        # remain visible in the preview strip.
        max_page_height = 0.0
        for index in range(shown_pages):
            page_height = float(doc[index].rect.height)
            if page_height > max_page_height:
                max_page_height = page_height

        common_scale = 1.0
        if max_page_height > 0 and max_height > 0:
            common_scale = min(1.0, float(max_height) / max_page_height)

        render_scale = common_scale * PDF_PREVIEW_RENDER_QUALITY_MULTIPLIER
        render_scale = max(PDF_PREVIEW_MIN_RENDER_SCALE, render_scale)
        render_scale = min(PDF_PREVIEW_MAX_RENDER_SCALE, render_scale)

        if max_page_height > 0:
            capped_scale = float(PDF_PREVIEW_MAX_RENDER_HEIGHT) / max_page_height
            render_scale = min(render_scale, max(0.05, capped_scale))
            render_scale = max(0.05, render_scale)

        for index in range(shown_pages):
            page = doc[index]
            pix = page.get_pixmap(matrix=fitz.Matrix(render_scale, render_scale), alpha=False)
            rgb_pix = pix if pix.n == 3 and not pix.alpha else fitz.Pixmap(fitz.csRGB, pix)
            bitmap = wx.Bitmap.FromBuffer(rgb_pix.width, rgb_pix.height, rgb_pix.samples)
            previews.append((index + 1, bitmap))

        return page_count, shown_pages, previews
    finally:
        doc.close()
